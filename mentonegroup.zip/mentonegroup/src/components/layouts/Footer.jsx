// src/components/layout/Footer.jsx
import { Link } from 'react-router-dom';
import { FaFacebook, FaTwitter, FaLinkedin, FaInstagram, FaEnvelope, FaPhone, FaMapMarkerAlt } from 'react-icons/fa';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-dark text-white">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <Link to="/" className="flex items-center">
              <img src="/images/logo.svg" alt="Mentone Group" className="h-10" />
              <span className="ml-2 font-heading font-bold text-xl">Mentone Group</span>
            </Link>
            <p className="mt-4 text-gray-400">
              A dynamic conglomerate with diverse businesses spanning multiple industries, united by a commitment to excellence and innovation.
            </p>
            <div className="mt-4 flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <FaFacebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <FaTwitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <FaLinkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <FaInstagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Our Companies</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/company/mentone-concrete" className="text-gray-400 hover:text-white transition-colors">
                  Mentone Concrete
                </Link>
              </li>
              <li>
                <Link to="/company/mentone-aluform" className="text-gray-400 hover:text-white transition-colors">
                  Mentone Aluform
                </Link>
              </li>
              <li>
                <Link to="/company/mentone-surgical" className="text-gray-400 hover:text-white transition-colors">
                  Mentone Surgical
                </Link>
              </li>
              <li>
                <Link to="/company/jeaplast" className="text-gray-400 hover:text-white transition-colors">
                  Jeaplast
                </Link>
              </li>
              <li>
                <Link to="/company/oriflame-studio" className="text-gray-400 hover:text-white transition-colors">
                  Oriflame Studio
                </Link>
              </li>
              <li>
                <Link to="/company/pgp-awar-foundation" className="text-gray-400 hover:text-white transition-colors">
                  PGP Awar Foundation
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <FaMapMarkerAlt className="w-5 h-5 text-secondary mt-1 mr-3" />
                <span className="text-gray-400">123 Business Park, Corporate Avenue, Mumbai, India</span>
              </li>
              <li className="flex items-center">
                <FaPhone className="w-5 h-5 text-secondary mr-3" />
                <span className="text-gray-400">+91 22 1234 5678</span>
              </li>
              <li className="flex items-center">
                <FaEnvelope className="w-5 h-5 text-secondary mr-3" />
                <span className="text-gray-400">info@mentonegroup.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter Signup */}
          <div>
            <h3 className="text-lg font-bold mb-4">Stay Updated</h3>
            <p className="text-gray-400 mb-4">Subscribe to our newsletter for the latest updates.</p>
            <form className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="px-4 py-2 bg-gray-800 text-white rounded-md focus:outline-none focus:ring-2 focus:ring-secondary"
                required
              />
              <button
                type="submit"
                className="bg-secondary hover:bg-secondary/90 text-white px-4 py-2 rounded-md transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-gray-800 text-center">
          <p className="text-gray-400">
            © {currentYear} Mentone Group. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
