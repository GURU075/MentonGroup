// src/components/ui/HeroSection.jsx
import { motion } from 'framer-motion';
import Button from './Button';

const HeroSection = ({ 
  title, 
  subtitle, 
  buttonText = 'Learn More', 
  buttonLink = '#', 
  backgroundImage = '/images/hero-bg.jpg',
  overlay = true,
  height = 'lg',
  align = 'center'
}) => {
  const heightClasses = {
    sm: 'h-[300px] md:h-[400px]',
    md: 'h-[400px] md:h-[500px]',
    lg: 'h-[500px] md:h-[600px]',
    xl: 'h-[600px] md:h-[700px]',
    full: 'h-screen'
  };
  
  const alignClasses = {
    left: 'text-left items-start',
    center: 'text-center items-center',
    right: 'text-right items-end'
  };
  
  return (
    <div 
      className={`relative flex items-center ${heightClasses[height]} overflow-hidden`}
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      {overlay && (
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
      )}
      
      <div className="container relative z-10">
        <div className={`flex flex-col ${alignClasses[align]} max-w-3xl mx-auto`}>
          <motion.h1 
            className="text-white mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {title}
          </motion.h1>
          
          <motion.p 
            className="text-white/90 text-lg md:text-xl mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            {subtitle}
          </motion.p>
          
          {buttonText && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Button to={buttonLink} variant="secondary" className="text-base md:text-lg px-8 py-3">
                {buttonText}
              </Button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HeroSection;