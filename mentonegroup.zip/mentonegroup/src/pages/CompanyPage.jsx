// src/pages/CompanyPage.jsx
import { useEffect } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { companiesData } from '../data/companiesData'; // Adjust the import path as necessary
import CompanyHeader from '../components/company/CompanyHeader';
import CompanyProducts from '../components/company/CompanyProducts';
import CompanyContactForm from '../components/company/CompanyContactForm';

const CompanyPage = () => {
  const { companyId } = useParams();
  const company = companiesData.find((company) => company.id === companyId);
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [companyId]);
  
  if (!company) {
    return <Navigate to="/not-found" />;
  }
  
  return (
    <>
      <Helmet>
        <title>{company.name} | Mentone Group</title>
        <meta name="description" content={company.description} />
      </Helmet>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <CompanyHeader company={company} />
        <CompanyProducts company={company} />
        <CompanyContactForm company={company} />
      </motion.div>
    </>
  );
};

export default CompanyPage;

