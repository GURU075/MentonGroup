// src/components/sections/CompaniesSection.jsx
import { motion } from 'framer-motion';
import CompanyCard from '../ui/CompanyCard';
import { companiesData } from '../../utils/data';

const CompaniesSection = ({ showAll = false, featured = true }) => {
  // Filter companies based on props
  const filteredCompanies = showAll 
    ? companiesData 
    : featured 
      ? companiesData.filter(company => company.featured)
      : companiesData.slice(0, 3);

  return (
    <section className="section">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="mb-4">Our Companies</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Discover our diverse portfolio of innovative businesses spanning multiple industries,
            each committed to excellence and leadership in their respective fields.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
          {filteredCompanies.map((company, index) => (
            <motion.div
              key={company.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <CompanyCard company={company} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CompaniesSection;